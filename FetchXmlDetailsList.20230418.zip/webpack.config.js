// eslint-disable-next-line no-undef
module.exports = {
    resolve: {
        // eslint-disable-next-line no-undef
        fallback: { "crypto": false },  
    }
}