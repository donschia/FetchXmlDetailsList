/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    FetchXML: ComponentFramework.PropertyTypes.StringProperty;
    RecordIdPlaceholder: ComponentFramework.PropertyTypes.StringProperty;
    ControlAnchorField: ComponentFramework.PropertyTypes.StringProperty;
    ColumnLayoutJson: ComponentFramework.PropertyTypes.StringProperty;
    ItemsPerPage: ComponentFramework.PropertyTypes.WholeNumberProperty;
    DebugMode: ComponentFramework.PropertyTypes.EnumProperty<"0" | "1">;
}
export interface IOutputs {
    ControlAnchorField?: string;
}
